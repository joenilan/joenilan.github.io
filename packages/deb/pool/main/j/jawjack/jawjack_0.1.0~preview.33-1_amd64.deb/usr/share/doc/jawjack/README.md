# Jawjack

Jawjack by Zombie Digital is a native Rust + GPUI Kit Twitch client being built as
Joe's Chatterino7 replacement. It combines dark Studio styling, a custom Windows
frame and a compact channel-first layout. The original C++ application is untouched.

## Chat and workspaces

- Channel tabs with context menus, drag reordering and middle-click close confirmation.
- Recursive resizable splits and tab groups: drag to an edge to split or to the
  center/tab strip to combine. No artificial two-pane limit.
- Named workspaces managed in a collapsible, animated sidebar. The titlebar
  hamburger remembers whether it is open; there is no duplicate workspace tab bar.
- Independent channel drafts and reply targets, including across workspaces.
- Soft-wrapping composers with Twitch's 500-character message limit, ordinary
  editing shortcuts and saved drafts. Pasted line breaks become spaces.
- Live incoming chat with username colors, badges, animated Twitch/7TV emotes,
  BTTV/FFZ catalogs, a searchable emote picker and keyboard emote completion.
- Bounded slide-and-fade message entrances, visible-media animation and
  reduced-motion behavior. Retained chat history is bounded.
- Transcript selection, right-click copying with feedback, retained-message Find,
  message actions, local chatter cards, replies and retained conversation views.
- Live-only channel filtering and compact layouts down to 360×280. Normal startup
  size is 1280×820; compact support does not force a small window.
- Latest source adds unread/activity views, mention/word highlighting, font
  shortcuts and pastel live/offline/unknown indicators. Named native Windows checks have passed; remaining edge cases are recorded in
  the evidence log.

This is still a development client. Full Chatterino7 parity, modern Twitch rich
messages, moderation and additional providers are tracked in the
[master feature plan](docs/FEATURE_COVERAGE.md). Planned
[Viewer, Moderator and Streamer experiences](docs/ROLE_EXPERIENCES.md) and
[multiservice chat](docs/MULTIPLATFORM.md) extend that scope. A listed plan is not
a shipped feature.

## Twitch connection

Device-code sign-in uses Jawjack's public Client ID and the OS credential vault.
No client secret is embedded. Native Windows sign-in, saved-login restoration,
authenticated incoming chat and animated Twitch/7TV media have been observed.
DinoDance animation has also been observed in the picker.

Sending is implemented with draft-preserving failure/uncertainty handling, but
actual delivered sends remain unverified. Broader refresh/revocation recovery and
moderation behavior still need real-use evidence. BTTV/FFZ catalog loading is
observed; individual provider rendering coverage remains incomplete.

See [account details](docs/TWITCH_ACCOUNT.md) and the dated
[native evidence record](docs/VALIDATION.md) for precise limits.

## Build and run

Use Rust 1.99.0 and GPUI Kit 0.7.1. Native Linux builds require the GPUI system
libraries. Native Windows builds use MSVC, Visual Studio C++ tools, the Windows SDK
and CMake; Windows can also be cross-compiled with cargo-xwin. From this directory:

```sh
python3 scripts/Run-Dev.py
```

The development runner uses `target/development` and `--profile dev`, keeping
both its executable and settings separate from the everyday app. It works for
native Linux development too. It enables the `dev-providers` Cargo feature so native
YouTube and Kick appear in Connections and can be debugged. They additionally
require an app profile named `dev` or `dev-*`; even this binary leaves them off
in ordinary profiles. Equivalent Linux commands are:

```sh
CARGO_TARGET_DIR="$PWD/target/development" cargo build -p chat-workbench --release --locked --features dev-providers
./target/development/release/chat-workbench --profile dev
```

Normal release builds omit `dev-providers`. YouTube and Kick stay visible as
grayed-out **Coming soon** cards in Connections and settings search. Their setup,
credential restoration, receive, send and moderation stay disabled there,
including with a `dev` profile. Saved native tabs and drafts are preserved but inactive. This does
not disable existing Streamer.bot events from those services. Real Kick operation
still requires the configured relay; enabling the Dev UI does not deploy it.
On Windows use the same Cargo feature and isolated app profile (with MSVC or
`cargo xwin build --target x86_64-pc-windows-msvc`).

The title-bar avatar opens that same Connections home. Twitch remains the primary
login; adding, managing and switching Twitch accounts now happens inline under
Connections → Twitch, alongside the service's connection diagnostics.
The overview summarizes ready, connecting, inactive and upcoming services.
**Review issues** opens the first current warning's troubleshooting details.

Development builds must not replace the everyday executable or launcher.
Accumulate local commits; pushing and publishing wait for the owner's direction.
Only install an update with a new version when the owner is ready to publish and
install the batch. The existing `Install-LinuxDesktop.py` changes the everyday
launcher and is not a development setup step.
Linux custom frames request client decorations; active dialogs keep their backdrop
clicks instead of passing them to native window dragging or resizing.
Linux viewer cards also dismiss on titlebar clicks, consuming that caption gesture
so it cannot move, resize or close the app. Other dialogs keep their own policies.
Keep the normal `XDG_CONFIG_HOME`
so desktop preferences such as the default browser remain visible.

Settings → Connections starts with a compact service overview: Twitch and YouTube,
OBS Studio and Streamer.bot, and emote providers. Open a service for its account,
setup and connection details; All services returns to the overview. YouTube keeps
Google sign-in, read-only API-key setup and live chat status together. Settings
search finds controls within every service and links to the matching service or
page. Connection troubleshooting stays collapsed until opened or reached from
search; primary access, status and recovery controls remain visible. Services have
icons and plain-language status labels. Search and section tooltips remain
available in narrow windows. About includes the build version,
existing updater, published notes, notices and support summary. Rendering these
pages adds no network polling. Recovery actions reuse the existing workers and
their request pacing.

The native Windows development executable is
`target/development/release/chat-workbench.exe` under this directory.
The project has built on Linux and Windows; platform acceptance is recorded per
revision. Build and directly interact with the actual app for development.
Commits use `[skip ci]`; no CI/Actions or separate test-script workflow is required.
Optional session-only native app control is described in
[APP_CONTROL.md](docs/APP_CONTROL.md).

## Shortcuts

- Ctrl+T: new workspace
- Ctrl+W: close workspace
- Ctrl+Shift+T: reopen recently closed workspace
- Ctrl+Tab / Ctrl+Shift+Tab: next / previous channel tab in the focused split
- Mouse wheel on a channel tab strip: wheel down / up moves forward / backward
- Ctrl+PageDown / Ctrl+PageUp: alternate next / previous channel shortcuts
- Ctrl+Alt+PageDown / Ctrl+Alt+PageUp: next / previous workspace
- Ctrl+P: search and switch existing channels across workspaces
- Ctrl+K: add channel
- Ctrl+I: details for the focused channel
- Composer @name: recent-speaker suggestions; :emote or Tab: emote completion
- Alt+Up / Alt+Down in composer: recall successful sends and return to your draft
- Ctrl+F: find retained messages; F3 / Shift+F3: next / previous match
- Titlebar bell: only mentions, replies to you and highlights opted into Mentions;
  the bell count shows unread mentions without an @ prefix.
- Ctrl+Shift+M: broader Highlights & unread activity; Ctrl+Shift+R: mark all read
- Ctrl+wheel or Ctrl+= / Ctrl+-: transcript font size; Ctrl+0: reset (latest source)
- Transcript Ctrl+A selects retained messages; Ctrl+C, Ctrl+Insert or right-click
  copies. Escape clears selection or dismisses the active interaction.
- Composer uses ordinary editing shortcuts. Text wraps visually; Shift+Enter
  does not create a multiline Twitch message.

Appearance also offers optional local-time timestamps, with or without seconds.

Find supports [author, badge, content filters and quoted phrases](docs/CHAT_SEARCH.md).
Message menus and chatter cards can jump directly to that person’s retained history.

## Local storage

Windows settings are stored in `%LOCALAPPDATA%\ChatWorkbench\workspace.json`.
A previous-file backup is kept before replacement. Drafts and reply-target metadata
are plaintext local application data, not credentials. Invalid or unsupported
settings files are preserved and saving is disabled for that run with an explanation.
Twitch tokens use a separate OS-vault entry and never enter workspace.json.

Workspaces, layouts, preferences and drafts restore after relaunch. Recently closed
workspace reopening and unread counters are session-local. Closing a split preserves
its draft for reopening in that workspace. Native QA may use an isolated profile.

## Roadmap

- [Complete feature coverage and delivery order](docs/FEATURE_COVERAGE.md)
- [Architecture and design decisions](docs/PLAN.md)
- [Multiplatform chat direction](docs/MULTIPLATFORM.md)
- [Viewer, Moderator and Streamer experience plan](docs/ROLE_EXPERIENCES.md)

Accessibility/IME, full Unicode selection, richer media and provider behavior,
moderation, multiwindow workflows and daily-client parity remain active work.

Local composer commands and keyboard completion are described in [Composer commands](docs/COMPOSER_COMMANDS.md). Unsupported slash commands keep your draft and never fall through to public chat.

## Linux and Windows previews

Jawjack previews are published for Windows x64 and Linux x86_64. Windows keeps its
per-user installer, portable ZIP and existing in-app update feed. Linux uses a
versioned archive built on Fedora 44; it is not a universal static build.
From .21, the installed default-profile Linux copy supports verified in-app
update downloads and confirmed installation/relaunch, using Python 3.
Linux .20 and older need one manual installation of .21 to gain this support.
The Linux feed is `https://apps.zombie.digital/downloads/jawjack/linux/latest.json`.
Its `archive` field is relative to that feed's directory.

Extract the Linux archive and run `python3 install.py`. It verifies the package,
installs into a new `~/.local/share/jawjack/versions/<version>` directory (respecting
`XDG_DATA_HOME`), backs up the previous desktop launcher and registers the branded
icon. It refuses to overwrite an installed version and does not restart the app
or change settings/sign-ins. Close and reopen Jawjack to use the installed version.

Release tooling:

- `scripts/Package-Release.py --no-build` packages existing Windows app/setup
  binaries from `JAWJACK_TARGET_DIR` (default `target/development`). On Linux it
  uses Wine only for the read-only assembled-installer payload check.
- `scripts/Package-Linux.py --binary <binary> --notes-file <notes> --source-commit <commit>`
  creates the Linux companion under `release-out/<version>/linux`.
- `scripts/Publish-Linux.py --release-dir <linux-output>` validates without
  connecting. Explicit `--publish` with release-server configuration uploads a
  new immutable Linux archive and activates its independent metadata, after the
  matching Windows release is published. It does not change the Windows feed.
- The current GPUI Windows backend needs precompiled shader bytecode when built
  from Linux. The local cross-build cache contains the validated output generated
  with Microsoft's D3D compiler under Wine; the transferable build details remain
  in `target/dist/CROSS-BUILD-HANDOFF.txt`. A fresh cache needs that generation step.

Publication, version bumps and installation require the owner's release direction.
Native Windows runtime and visual review are separate from cross-compilation,
Wine installer checks and automated Linux interaction checks.
