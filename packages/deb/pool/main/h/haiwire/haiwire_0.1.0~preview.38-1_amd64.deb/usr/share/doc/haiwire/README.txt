Haiwire, a native terminal-first coding workspace.

Installed by your package manager (dnf, apt or pacman). Haiwire does not
download or install updates for this copy; update it with your system updates.
Your profiles, transcripts and credentials live in your home directory and
desktop keyring and are not removed when the package is removed.

Requirements: a graphical session (Wayland or X11) with a Vulkan driver,
/usr/bin/curl, and secret-tool plus a Secret Service provider (for example
gnome-keyring or KWallet's Secret Service) for stored credentials. git is
recommended.

This package is unsigned unless the repository you installed it from signs it.
Haiwire is proprietary; see COPYRIGHT. Third-party notices: THIRD_PARTY_NOTICES.txt.
Run it with: haiwire
